SNOW WHITE GAME - SINGLE FILE
Upload only index.html to the root of your GitHub Pages repository. All 13 PNG images are embedded in this file. No images folder is necessary.
